// Simple and reliable map initialization
let map;
let markers = [];
let locations = [];

// Sample locations data
const sampleLocations = [
  {
    id: 1,
    name: "New Delhi",
    category: "capital",
    lat: 28.6139,
    lng: 77.2090,
    description: "Capital city of India, known for its rich history and government buildings.",
    image: "https://images.pexels.com/photos/789750/pexels-photo-789750.jpeg?auto=compress&cs=tinysrgb&w=500&h=300"
  },
  {
    id: 2,
    name: "Mumbai",
    category: "city",
    lat: 19.0760,
    lng: 72.8777,
    description: "Financial capital of India and home to Bollywood.",
    image: "https://images.pexels.com/photos/3581368/pexels-photo-3581368.jpeg?auto=compress&cs=tinysrgb&w=500&h=300"
  },
  {
    id: 3,
    name: "Bangalore",
    category: "city",
    lat: 12.9716,
    lng: 77.5946,
    description: "Silicon Valley of India, major IT hub.",
    image: "https://images.pexels.com/photos/3581368/pexels-photo-3581368.jpeg?auto=compress&cs=tinysrgb&w=500&h=300"
  },
  {
    id: 4,
    name: "Taj Mahal",
    category: "landmark",
    lat: 27.1751,
    lng: 78.0421,
    description: "Iconic white marble mausoleum in Agra, UNESCO World Heritage Site.",
    image: "https://images.pexels.com/photos/1583339/pexels-photo-1583339.jpeg?auto=compress&cs=tinysrgb&w=500&h=300"
  },
  {
    id: 5,
    name: "Kerala Backwaters",
    category: "attraction",
    lat: 9.4981,
    lng: 76.3388,
    description: "Network of brackish lagoons and lakes in Kerala.",
    image: "https://images.pexels.com/photos/962464/pexels-photo-962464.jpeg?auto=compress&cs=tinysrgb&w=500&h=300"
  }
];

// Initialize map when page loads
document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM loaded, initializing map...');
  initMap();
});

function initMap() {
  try {
    console.log('Creating map...');
    
    // Create map
    map = L.map('map').setView([20.5937, 78.9629], 5);
    
    console.log('Adding tile layer...');
    
    // Add tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 18
    }).addTo(map);
    
    console.log('Loading locations...');
    
    // Load locations
    locations = sampleLocations;
    addMarkers();
    
    console.log('Setting up event listeners...');
    
    // Setup event listeners
    setupEventListeners();
    
    console.log('Hiding loading overlay...');
    
    // Hide loading overlay
    setTimeout(() => {
      const loadingOverlay = document.getElementById('loadingOverlay');
      if (loadingOverlay) {
        loadingOverlay.style.display = 'none';
      }
    }, 1000);
    
    console.log('Map initialization complete!');
    
  } catch (error) {
    console.error('Error initializing map:', error);
    
    // Hide loading overlay even on error
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
      loadingOverlay.innerHTML = '<div class="spinner"></div><p>Error loading map. Please refresh the page.</p>';
    }
  }
}

function addMarkers() {
  console.log('Adding markers...');
  
  locations.forEach(location => {
    // Create marker
    const marker = L.marker([location.lat, location.lng])
      .addTo(map)
      .bindPopup(`
        <div style="text-align: center;">
          <h4 style="margin: 0 0 8px 0; color: #2563eb;">${location.name}</h4>
          <p style="margin: 0 0 8px 0; font-size: 14px;">${location.description}</p>
          <button onclick="showLocationDetails(${location.id})" 
                  style="background: #2563eb; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer;">
            View Details
          </button>
        </div>
      `);
    
    markers.push({ marker, location });
  });
  
  console.log(`Added ${markers.length} markers`);
}

function showLocationDetails(locationId) {
  const location = locations.find(loc => loc.id === locationId);
  if (!location) return;
  
  console.log('Showing details for:', location.name);
  
  // Update info panel
  document.getElementById('locationName').textContent = location.name;
  document.getElementById('locationCategory').textContent = location.category;
  document.getElementById('locationCategory').className = `category-badge category-${location.category}`;
  document.getElementById('locationDescription').textContent = location.description;
  document.getElementById('locationImg').src = location.image;
  document.getElementById('locationImg').alt = location.name;
  document.getElementById('locationCoords').textContent = `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`;
  
  // Show info panel
  const infoPanel = document.getElementById('locationInfo');
  infoPanel.classList.remove('hidden');
  
  // Center map on location
  map.setView([location.lat, location.lng], 10);
}

function hideLocationInfo() {
  document.getElementById('locationInfo').classList.add('hidden');
}

function setupEventListeners() {
  // Search functionality
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  
  function performSearch() {
    const query = searchInput.value.toLowerCase().trim();
    console.log('Searching for:', query);
    
    if (!query) {
      // Show all markers
      markers.forEach(({ marker }) => {
        marker.addTo(map);
      });
      map.setView([20.5937, 78.9629], 5);
      return;
    }
    
    // Filter locations
    const filteredLocations = locations.filter(location =>
      location.name.toLowerCase().includes(query) ||
      location.category.toLowerCase().includes(query) ||
      location.description.toLowerCase().includes(query)
    );
    
    console.log('Found locations:', filteredLocations.length);
    
    // Remove all markers
    markers.forEach(({ marker }) => {
      map.removeLayer(marker);
    });
    
    // Add filtered markers
    filteredLocations.forEach(location => {
      const markerData = markers.find(m => m.location.id === location.id);
      if (markerData) {
        markerData.marker.addTo(map);
      }
    });
    
    // Center map on results
    if (filteredLocations.length === 1) {
      const location = filteredLocations[0];
      map.setView([location.lat, location.lng], 10);
      setTimeout(() => showLocationDetails(location.id), 500);
    } else if (filteredLocations.length > 1) {
      const group = new L.featureGroup(
        filteredLocations.map(loc => L.marker([loc.lat, loc.lng]))
      );
      map.fitBounds(group.getBounds().pad(0.1));
    }
  }
  
  searchBtn.addEventListener('click', performSearch);
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      performSearch();
    }
  });
  
  // Filter buttons
  const filterButtons = document.querySelectorAll('.filter-btn');
  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const category = btn.getAttribute('data-category');
      console.log('Filtering by:', category);
      
      // Update active button
      filterButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      // Clear search
      searchInput.value = '';
      
      // Filter markers
      if (category === 'all') {
        markers.forEach(({ marker }) => {
          marker.addTo(map);
        });
        map.setView([20.5937, 78.9629], 5);
      } else {
        // Remove all markers
        markers.forEach(({ marker }) => {
          map.removeLayer(marker);
        });
        
        // Add filtered markers
        const filteredMarkers = markers.filter(({ location }) => location.category === category);
        filteredMarkers.forEach(({ marker }) => {
          marker.addTo(map);
        });
        
        // Fit map to filtered markers
        if (filteredMarkers.length > 0) {
          const group = new L.featureGroup(filteredMarkers.map(({ marker }) => marker));
          map.fitBounds(group.getBounds().pad(0.1));
        }
      }
    });
  });
  
  // Close info panel
  document.getElementById('closeInfo').addEventListener('click', hideLocationInfo);
  
  // Close on overlay click
  document.addEventListener('click', (e) => {
    if (e.target.id === 'locationInfo') {
      hideLocationInfo();
    }
  });
  
  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      hideLocationInfo();
    }
  });
}

// Make function globally accessible
window.showLocationDetails = showLocationDetails;